-- AlterTable
ALTER TABLE "subscriptions" ALTER COLUMN "userId" DROP NOT NULL;
