import express from "express";
import { DocumentController } from "./document.controller";
import catchAsync from "../../shared/catchAsync";
import auth from "../../middlewares/auth";
import upload from "../../middlewares/upload";

const router = express.Router();

// Profile document routes
router.post(
  "/profile/:userId",
  auth(),
  upload.single('document'), // Add multer middleware to handle file upload
  catchAsync(DocumentController.addDocumentToProfile)
);

router.get(
  "/profile/:userId",
  auth(),
  catchAsync(DocumentController.getProfileDocuments)
);

// Company document routes - using userId since company isn't created yet
router.post(
  "/company/:userId",
  auth(),
  upload.single('company-file'), // Changed field name to match frontend/Postman
  catchAsync(DocumentController.addDocumentToCompany)
);

router.get(
  "/company/:userId",
  auth(),
  catchAsync(DocumentController.getCompanyDocuments)
);

// Generic document routes
router.delete(
  "/:documentId",
  auth(),
  catchAsync(DocumentController.deleteDocument)
);

export const DocumentRoutes = router;
