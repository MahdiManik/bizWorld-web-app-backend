import { PrismaClient } from "@prisma/client";
import { Request } from "express";
import httpStatus from "http-status";
import { ApiError } from "../../../middleware/error/errorHandler";

const prisma = new PrismaClient();

// Create a new category
const createCategory = async (req: Request) => {
  const { name } = req.body;

  // Check if category with the same name already exists
  const existingCategory = await prisma.listingCategory.findUnique({
    where: { name },
  });

  if (existingCategory) {
    throw new ApiError("Category with this name already exists", httpStatus.CONFLICT);
  }

  // Create new category
  const category = await prisma.listingCategory.create({
    data: { name },
  });

  return category;
};

// Get all categories
const getAllCategories = async () => {
  const categories = await prisma.listingCategory.findMany({
    include: {
      _count: {
        select: { listings: true }
      }
    },
  });

  return categories;
};

// Get category by ID
const getCategory = async (categoryId: string) => {
  const category = await prisma.listingCategory.findUnique({
    where: { id: categoryId },
    include: {
      listings: {
        include: {
          company: true,
          owner: true,
          financialMetric: true
        }
      },
      _count: {
        select: { listings: true }
      }
    },
  });

  if (!category) {
    throw new ApiError("Category not found", httpStatus.NOT_FOUND);
  }

  return category;
};

// Update category
const updateCategory = async (req: Request) => {
  const { categoryId } = req.params;
  const { name } = req.body;

  // Check if category exists
  const category = await prisma.listingCategory.findUnique({
    where: { id: categoryId },
  });

  if (!category) {
    throw new ApiError("Category not found", httpStatus.NOT_FOUND);
  }

  // Check if another category with the new name already exists
  if (name && name !== category.name) {
    const existingCategory = await prisma.listingCategory.findUnique({
      where: { name },
    });

    if (existingCategory) {
      throw new ApiError("Category with this name already exists", httpStatus.CONFLICT);
    }
  }

  // Update category
  const updatedCategory = await prisma.listingCategory.update({
    where: { id: categoryId },
    data: { name },
  });

  return updatedCategory;
};

// Delete category
const deleteCategory = async (categoryId: string) => {
  // Check if category exists
  const category = await prisma.listingCategory.findUnique({
    where: { id: categoryId },
    include: {
      _count: {
        select: { listings: true }
      }
    }
  });

  if (!category) {
    throw new ApiError("Category not found", httpStatus.NOT_FOUND);
  }

  // Check if category is being used by any listings
  if (category._count.listings > 0) {
    throw new ApiError(
      "Cannot delete category that is assigned to listings. Remove the category from all listings first.",
      httpStatus.BAD_REQUEST
    );
  }

  // Delete category
  const deletedCategory = await prisma.listingCategory.delete({
    where: { id: categoryId },
  });

  return {
    message: "Category deleted successfully",
    category: deletedCategory,
  };
};

export const ListingCategoryService = {
  createCategory,
  getAllCategories,
  getCategory,
  updateCategory,
  deleteCategory,
};
